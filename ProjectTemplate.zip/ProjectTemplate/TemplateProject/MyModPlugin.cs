﻿using System.IO;
using System.Reflection;
using System.Security;
using System.Security.Permissions;
using BepInEx;
using BepInEx.Logging;
using CommonAPI;
using CommonAPI.Systems;
using HarmonyLib;
using UnityEngine;
using xiaoye97;

[module: UnverifiableCode]
#pragma warning disable 618
[assembly: SecurityPermission(SecurityAction.RequestMinimum, SkipVerification = true)]
#pragma warning restore 618

namespace MyMod
{
    [BepInPlugin(MODGUID, MOD_DISP_NAME, VERSION)]
    [BepInDependency(LDBToolPlugin.MODGUID)]
    [BepInDependency(CommonAPIPlugin.GUID)]
    [CommonAPISubmoduleDependency(nameof(ProtoRegistry))]
    public class MyModPlugin : BaseUnityPlugin
    {
        public const string MODNAME = "MyMod";
        
        public const string MODGUID = "my.mod.guid";
        
        public const string MOD_DISP_NAME = "My Mod";
        
        public const string VERSION = "1.0.0";


		public static ManualLogSource logger;

        private void Awake()
        {
            logger = Logger;

            Harmony harmony = new Harmony(MODGUID);
            harmony.PatchAll(Assembly.GetExecutingAssembly());
            logger.LogInfo("My mod is loaded");
        }
    }
}